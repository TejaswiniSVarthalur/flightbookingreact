import React, { Component } from "react";
import axios from "axios";

const url = "http://localhost:1050/updatebooking/";

class UpdateBooking extends Component {
    constructor(props) {
        super(props);
        this.state = {
            form: {
                bookingId: "",
                noOfTickets: ""
            },
            formErrorMessage: {
                bookingId: "",
                noOfTickets: ""
            },
            formValid: {
                bookingId: true,
                noOfTickets: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: "",
            id: this.props.match.params.bookingId
        };
    }

    componentDidMount() {
        const { form } = this.state
        this.setState({ form: { ...form, bookingId: this.state.id } });
    }

    updateBooking = () => {
        this.setState({ successMessage: "", errorMessage: "" })
        axios.put(url + this.state.form.bookingId, this.state.form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.updateBooking();
    }

    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const { form } = this.state;
        this.setState({
            form: { ...form, [name]: value }
        });
        this.validateField(name, value);
    }

    validateField = (fieldName, value) => {
        let fieldValidationErrors = this.state.formErrorMessage;
        let formValid = this.state.formValid;

        switch (fieldName) {
            case "noOfTickets":
                if (value === "") {
                    fieldValidationErrors.noOfTickets = "field required";
                    formValid.noOfTickets = false;
                } else if (value <= 0 || value > 10) {
                    fieldValidationErrors.noOfTickets = "No of tickets should be greater than 0 and less than 10";
                    formValid.noOfTickets = false;
                } else {
                    fieldValidationErrors.noOfTickets = "";
                    formValid.noOfTickets = true;
                }
                break;
            default:
                break;
        }
        formValid.buttonActive = formValid.noOfTickets;
        this.setState({
            formErrorMessage: fieldValidationErrors,
            formValid: formValid,
            successMessage: ""
        });
    }

    render() {
        return (
            <React.Fragment>
                <div className="UpdateBooking">
                    <div className="row">
                        <div className="col-md-6 offset-md-3">
                            <br />
                            <div className="card">
                                <div className="card-header bg-custom">
                                    <h4>Update Flight Booking for id: {this.state.id}</h4>
                                </div>
                                <div className="card-body">
                                    <form className="form" onSubmit={this.handleSubmit}>
                                        <div className="form-group">
                                            <label htmlFor="bookingId">bookingId</label>
                                            <input
                                                name="bookingId"
                                                id="bookingId"
                                                value={this.state.form.bookingId}
                                                onChange={this.handleChange}
                                                className="form-control"
                                                disabled
                                            />
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="noOfTickets">Number of Tickets</label>
                                            <input
                                                type="number"
                                                placeholder="min-1 max-10"
                                                name="noOfTickets"
                                                id="noOfTickets"
                                                value={this.state.form.noOfTickets}
                                                onChange={this.handleChange}
                                                className="form-control"
                                            />
                                            <span name="noOfTicketsError" className="text-danger">
                                                {this.state.formErrorMessage.noOfTickets}
                                            </span>
                                        </div>
                                        <button type="submit" className="btn btn-primary"
                                            disabled={!this.state.formValid.buttonActive}>Update Booking</button>
                                    </form>
                                </div>
                                <span className="text-success font-weight-bold message">
                                    {this.state.successMessage}
                                </span>
                                <span className="text-danger font-weight-bold message">
                                    {this.state.errorMessage}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default UpdateBooking;