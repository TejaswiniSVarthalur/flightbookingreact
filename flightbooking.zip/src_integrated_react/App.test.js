import React from "react";
import { shallow } from "enzyme";
import CreateBooking from "./components/CreateBooking";
import GetBookings from "./components/GetBookings";

// -----------------------------------------------------------------------------------
describe("CREATE BOOKING COMPONENT", () => {

  test("CBJT1-Create Booking component has a form", () => {
    const wrapper = shallow(<CreateBooking />);
    expect(wrapper.find("form")).toHaveLength(1);
  });

  test("CBJT2-Create Booking component has three fields (2 inputs & 1 dropdown)", () => {
    const wrapper = shallow(<CreateBooking />);
    expect(wrapper.find("form").find("input").length + wrapper.find("form").find("select").length).toEqual(3);
  });

  test("CBJT3-Create Booking component has a button", () => {
    const wrapper = shallow(<CreateBooking />);
    expect(wrapper.find("form").find("button")).toHaveLength(1);
  });


  test("CBJT4-Name prop of all the input fields is proper", () => {
    const wrapper = shallow(<CreateBooking />);
    let status = false;
    if (wrapper.find("form").find("input").at(0).props().name == "customerId" &&
      wrapper.find("form").find("input").at(1).props().name == "noOfTickets" &&
      wrapper.find("form").find("select").at(0).props().name == "flightId") { status = true; }
    expect(status).toEqual(true);
  });

  test("CBJT5-Error message tags for all the fields have proper name attribute", () => {
    const wrapper = shallow(<CreateBooking />);
    let formErrorMessage = Object.assign({}, wrapper.state().formErrorMessage);
    formErrorMessage.customerId = true;
    wrapper.setState({ formErrorMessage });
    expect(wrapper.find('[name="customerIdError"]').length +
      wrapper.find('[name="flightIdError"]').length + wrapper.find('[name="noOfTicketsError"]').length
    ).toEqual(3);
  });

  test("CBJT6-form level success and error messages of CreateBooking component have proper name attribute", () => {
    const wrapper = shallow(<CreateBooking />);
    wrapper.setState({ errorMessage: true });
    expect(wrapper.find('[name="errorMessage"]').length + wrapper.find('[name="successMessage"]').length).toEqual(2);
  });

  test("CBJT7-All input fields of CreateBooking component have formcontrol class", () => {
    const wrapper = shallow(<CreateBooking />);
    let customerId = wrapper.find('input[name="customerId"]').hasClass('form-control');
    let noOfTickets = wrapper.find('input[name="noOfTickets"]').hasClass('form-control');
    let flightId = wrapper.find('select[name="flightId"]').hasClass('form-control');
    expect(customerId && noOfTickets && flightId).toEqual(true);
  });
})

// describe("GET BOOKING COMPONENT", () => {

//   test("VBJT1-Get Booking component has a form", () => {
//     const wrapper = shallow(<GetBookings />);
//     expect(wrapper.find("form")).toHaveLength(1);
//   });

//   test("VBJT2-Get Booking component form has one input", () => {
//     const wrapper = shallow(<GetBookings />);
//     expect(wrapper.find("form").find("input")).toHaveLength(1);
//   });

//   test("VBJT3-Get Booking component form has a button", () => {
//     const wrapper = shallow(<GetBookings />);
//     expect(wrapper.find("form").find("button")).toHaveLength(1);
//   });

//   test("VBJT4-Button in Get Booking component form is of type submit", () => {
//     const wrapper = shallow(<GetBookings />);
//     expect(wrapper.find("button").props().type.toLowerCase()).toEqual("submit");
//   });

//   test("VBJT5-Table is not getting displayed on view component load", () => {
//     const wrapper = shallow(<GetBookings />);
//     expect(wrapper.find('table')).toHaveLength(0);
//   })
// })